# WhatsApp Chat Android APK

This is a small Android WebView app for:

`https://vijendarverma.in/chat/`

## Why this version fixes the keyboard issue

The Android activity explicitly uses:

- `SOFT_INPUT_ADJUST_RESIZE`
- `stateAlwaysHidden`
- a normal non-edge-to-edge AppCompat window
- a WebView that fills the resized activity

When the Android keyboard opens, Android resizes the WebView instead of panning
the entire activity. Your website's green header/chat/composer can therefore
use the reduced viewport normally.

## Build with GitHub Actions

1. Create a new GitHub repository.
2. Upload all files from this project to the repository.
3. Commit to `main`.
4. Open **Actions**.
5. Select **Build Android APK**.
6. Click **Run workflow** if needed.
7. After the build finishes, open the workflow run.
8. Download the artifact named **WhatsAppChat-debug-apk**.
9. Extract it and install `app-debug.apk`.

### Important

This project builds a new APK from source rather than modifying an existing
APK. It is therefore normally installable/uninstallable like a standard APK.

The APK loads the live website. If the website CSS/JS is changed later, the
APK does not need to be rebuilt.

For the best keyboard behavior, deploy the latest website-side mobile chat
fix to `https://vijendarverma.in/chat/` as well.
